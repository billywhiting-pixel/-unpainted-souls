# Unpainted Souls V6 Clean Studio Edition

This is the clean replacement build.

## Important GitHub upload instructions

Delete the old loose files first if possible, especially:

- Index.html.md
- RenderedImage.jpeg
- old app.js, audioEngine.js, guided.js, soundLibrary.js in the root
- old index.html

Then upload this exact folder structure:

- index.html
- manifest.json
- sw.js
- css/style.css
- js/audioEngine.js
- js/soundLibrary.js
- js/guided.js
- js/visualizer.js
- js/app.js
- assets/logo.jpeg

## Features

- Quick sessions
- Frequency mixer
- Sound library
- Binaural beats
- Guided voice
- Breath pacer
- Sleep timer with fade-out
- Saved sessions
- Cleaner service worker cache update
