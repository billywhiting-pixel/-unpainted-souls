const CACHE_NAME="unpainted-souls-v6-clean";
const ASSETS=[
  "./",
  "./index.html",
  "./manifest.json",
  "./css/style.css",
  "./js/audioEngine.js",
  "./js/soundLibrary.js",
  "./js/guided.js",
  "./js/visualizer.js",
  "./js/app.js",
  "./assets/logo.jpeg"
];
self.addEventListener("install",e=>{self.skipWaiting();e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(ASSETS)))});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k)))));self.clients.claim()});
self.addEventListener("fetch",e=>{e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)))});
