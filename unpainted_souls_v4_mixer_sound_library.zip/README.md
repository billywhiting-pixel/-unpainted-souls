# Unpainted Souls V4

## New features
- Professional mixer controls
- Reverb and delay effects
- Mute / solo / duplicate controls
- Sound library section
- Generated ocean, rain, wind, forest, fireplace
- Synth crystal bowl, Tibetan bowl, chimes, ambient pad
- Saved named sessions

## Upload to GitHub
Replace the existing files with this full folder structure:

- index.html
- manifest.json
- sw.js
- css/style.css
- js/audioEngine.js
- js/soundLibrary.js
- js/visualizer.js
- js/app.js
- assets/logo.jpeg

Important: upload folders exactly as shown.
