class UnpaintedAudioEngine {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.analyser = null;
    this.dryGain = null;
    this.reverbGain = null;
    this.delayGain = null;
    this.delay = null;
    this.feedback = null;
    this.convolver = null;
    this.layers = [];
    this.soundLayers = [];
    this.special = [];
    this.soloId = null;
  }

  init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();

      this.master = this.ctx.createGain();
      this.dryGain = this.ctx.createGain();
      this.reverbGain = this.ctx.createGain();
      this.delayGain = this.ctx.createGain();
      this.delay = this.ctx.createDelay(2);
      this.feedback = this.ctx.createGain();
      this.convolver = this.ctx.createConvolver();
      this.analyser = this.ctx.createAnalyser();

      this.analyser.fftSize = 128;
      this.master.gain.value = 0.8;
      this.dryGain.gain.value = 1;
      this.reverbGain.gain.value = 0.15;
      this.delayGain.gain.value = 0.08;
      this.delay.delayTime.value = 0.28;
      this.feedback.gain.value = 0.25;
      this.convolver.buffer = this.createImpulseResponse(2.5, 2.2);

      this.dryGain.connect(this.master);
      this.reverbGain.connect(this.convolver).connect(this.master);
      this.delayGain.connect(this.delay).connect(this.feedback).connect(this.delay);
      this.delay.connect(this.master);
      this.master.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") this.ctx.resume();
  }

  createImpulseResponse(duration, decay) {
    const length = this.ctx.sampleRate * duration;
    const impulse = this.ctx.createBuffer(2, length, this.ctx.sampleRate);
    for (let channel = 0; channel < 2; channel++) {
      const data = impulse.getChannelData(channel);
      for (let i = 0; i < length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
      }
    }
    return impulse;
  }

  connectToEffects(source) {
    source.connect(this.dryGain);
    source.connect(this.reverbGain);
    source.connect(this.delayGain);
  }

  setMasterVolume(value) {
    this.init();
    this.master.gain.setTargetAtTime(Number(value), this.ctx.currentTime, 0.03);
  }

  setReverb(value) {
    this.init();
    this.reverbGain.gain.setTargetAtTime(Number(value), this.ctx.currentTime, 0.03);
  }

  setDelay(value) {
    this.init();
    this.delayGain.gain.setTargetAtTime(Number(value), this.ctx.currentTime, 0.03);
  }

  fadeTo(value, seconds = 4) {
    this.init();
    this.master.gain.cancelScheduledValues(this.ctx.currentTime);
    this.master.gain.setValueAtTime(this.master.gain.value, this.ctx.currentTime);
    this.master.gain.linearRampToValueAtTime(Number(value), this.ctx.currentTime + seconds);
  }

  addFrequencyLayer(freq, wave = "sine", volume = 0.12, pan = 0) {
    this.init();
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const panner = this.ctx.createStereoPanner();

    osc.type = wave;
    osc.frequency.value = Number(freq);
    gain.gain.value = Number(volume);
    panner.pan.value = Number(pan);

    osc.connect(gain).connect(panner);
    this.connectToEffects(panner);
    osc.start();

    const layer = {
      id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random()),
      type: "frequency",
      freq:Number(freq), wave, volume:Number(volume), pan:Number(pan),
      muted:false, solo:false, osc, gain, panner
    };
    this.layers.push(layer);
    this.applyMuteSolo();
    return layer;
  }

  updateLayer(id, values) {
    const layer = this.layers.find(l => l.id === id) || this.soundLayers.find(l => l.id === id);
    if (!layer) return;

    if (values.freq !== undefined && layer.osc) {
      layer.freq = Number(values.freq);
      layer.osc.frequency.setTargetAtTime(layer.freq, this.ctx.currentTime, 0.03);
    }
    if (values.volume !== undefined) {
      layer.volume = Number(values.volume);
      layer.gain.gain.setTargetAtTime(layer.muted ? 0 : layer.volume, this.ctx.currentTime, 0.03);
    }
    if (values.pan !== undefined && layer.panner) {
      layer.pan = Number(values.pan);
      layer.panner.pan.setTargetAtTime(layer.pan, this.ctx.currentTime, 0.03);
    }
  }

  removeLayer(id, group = "frequency") {
    const arr = group === "sound" ? this.soundLayers : this.layers;
    const index = arr.findIndex(l => l.id === id);
    const layer = arr[index];
    if (!layer) return;
    this.stopLayerNodes(layer);
    arr.splice(index, 1);
    this.applyMuteSolo();
  }

  stopLayerNodes(layer) {
    ["osc","osc2","lfo","source"].forEach(k => {
      if (layer[k]) {
        try { layer[k].stop(); layer[k].disconnect(); } catch(e) {}
      }
    });
  }

  clearAllLayers() {
    this.layers.forEach(l => this.stopLayerNodes(l));
    this.soundLayers.forEach(l => this.stopLayerNodes(l));
    this.layers = [];
    this.soundLayers = [];
    this.soloId = null;
  }

  toggleMute(id) {
    const layer = [...this.layers, ...this.soundLayers].find(l => l.id === id);
    if (!layer) return;
    layer.muted = !layer.muted;
    this.applyMuteSolo();
  }

  toggleSolo(id) {
    this.soloId = this.soloId === id ? null : id;
    this.applyMuteSolo();
  }

  applyMuteSolo() {
    [...this.layers, ...this.soundLayers].forEach(layer => {
      const shouldPlay = !layer.muted && (!this.soloId || layer.id === this.soloId);
      if (layer.gain) layer.gain.gain.setTargetAtTime(shouldPlay ? layer.volume : 0, this.ctx.currentTime, 0.03);
    });
  }

  addGeneratedSound(kind, volume = 0.12, pan = 0) {
    this.init();
    const layer = window.SoundLibrary.create(this.ctx, kind, volume, pan);
    this.connectToEffects(layer.output);
    this.soundLayers.push(layer);
    this.applyMuteSolo();
    return layer;
  }

  startBinaural(carrierHz = 220, beatHz = 6, volume = 0.12) {
    this.init();
    const merger = this.ctx.createChannelMerger(2);
    const leftOsc = this.ctx.createOscillator();
    const rightOsc = this.ctx.createOscillator();
    const leftGain = this.ctx.createGain();
    const rightGain = this.ctx.createGain();

    leftOsc.frequency.value = Number(carrierHz);
    rightOsc.frequency.value = Number(carrierHz) + Number(beatHz);
    leftGain.gain.value = Number(volume);
    rightGain.gain.value = Number(volume);

    leftOsc.connect(leftGain).connect(merger, 0, 0);
    rightOsc.connect(rightGain).connect(merger, 0, 1);
    merger.connect(this.dryGain);

    leftOsc.start();
    rightOsc.start();

    const node = { type:"binaural", leftOsc, rightOsc, leftGain, rightGain, carrierHz:Number(carrierHz), beatHz:Number(beatHz), volume:Number(volume), merger };
    this.special.push(node);
    return node;
  }

  startIsochronic(carrierHz = 220, pulseHz = 6) {
    this.init();
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const lfo = this.ctx.createOscillator();
    const lfoGain = this.ctx.createGain();

    osc.type = "sine";
    osc.frequency.value = Number(carrierHz);
    lfo.type = "square";
    lfo.frequency.value = Number(pulseHz);
    lfoGain.gain.value = 0.11;
    gain.gain.value = 0.11;

    lfo.connect(lfoGain).connect(gain.gain);
    osc.connect(gain);
    this.connectToEffects(gain);
    osc.start();
    lfo.start();

    const node = { type:"isochronic", osc, gain, lfo, lfoGain, carrierHz:Number(carrierHz), pulseHz:Number(pulseHz) };
    this.special.push(node);
    return node;
  }

  stopSpecial() {
    this.special.forEach(node => {
      ["osc","lfo","leftOsc","rightOsc"].forEach(k => {
        if (node[k]) {
          try { node[k].stop(); node[k].disconnect(); } catch(e) {}
        }
      });
    });
    this.special = [];
  }

  stopAll() {
    this.clearAllLayers();
    this.stopSpecial();
  }

  snapshot() {
    return {
      layers: this.layers.map(l => ({ freq:l.freq, wave:l.wave, volume:l.volume, pan:l.pan })),
      soundLayers: this.soundLayers.map(l => ({ kind:l.kind, volume:l.volume, pan:l.pan })),
      masterVolume: this.master ? this.master.gain.value : 0.8,
      reverb: this.reverbGain ? this.reverbGain.gain.value : 0.15,
      delay: this.delayGain ? this.delayGain.gain.value : 0.08
    };
  }

  loadSnapshot(snapshot) {
    this.stopAll();
    (snapshot.layers || []).forEach(l => this.addFrequencyLayer(l.freq, l.wave, l.volume, l.pan));
    (snapshot.soundLayers || []).forEach(l => this.addGeneratedSound(l.kind, l.volume, l.pan));
    if (snapshot.masterVolume !== undefined) this.setMasterVolume(snapshot.masterVolume);
    if (snapshot.reverb !== undefined) this.setReverb(snapshot.reverb);
    if (snapshot.delay !== undefined) this.setDelay(snapshot.delay);
  }
}

window.audioEngine = new UnpaintedAudioEngine();
