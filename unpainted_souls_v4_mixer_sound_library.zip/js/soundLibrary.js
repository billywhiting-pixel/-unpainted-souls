window.SoundLibrary = {
  create(ctx, kind, volume = 0.12, pan = 0) {
    const id = crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random());
    const gain = ctx.createGain();
    const panner = ctx.createStereoPanner();
    const output = ctx.createGain();

    gain.gain.value = volume;
    panner.pan.value = pan;
    gain.connect(panner).connect(output);

    let layer = { id, type:"sound", kind, volume, pan, muted:false, gain, panner, output };

    if (["ocean","rain","wind","forest","fireplace"].includes(kind)) {
      const buffer = ctx.createBuffer(1, ctx.sampleRate * 5, ctx.sampleRate);
      const data = buffer.getChannelData(0);

      for (let i = 0; i < data.length; i++) {
        let n = Math.random() * 2 - 1;
        if (kind === "ocean") n *= Math.sin(i / 5200) * 0.55 + 0.45;
        if (kind === "wind") n *= Math.sin(i / 9500) * 0.45 + 0.25;
        if (kind === "forest") n *= (Math.random() > 0.995 ? 3 : 0.18);
        if (kind === "fireplace") n *= (Math.random() > 0.985 ? 2.8 : 0.12);
        data[i] = n;
      }

      const source = ctx.createBufferSource();
      const filter = ctx.createBiquadFilter();
      source.buffer = buffer;
      source.loop = true;
      filter.type = kind === "rain" || kind === "fireplace" ? "highpass" : "lowpass";
      filter.frequency.value = kind === "rain" ? 1500 : kind === "fireplace" ? 900 : 650;
      source.connect(filter).connect(gain);
      source.start();
      layer.source = source;
      layer.filter = filter;
    }

    if (["crystal","tibetan","chimes","pad"].includes(kind)) {
      const osc = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();

      if (kind === "crystal") {
        osc.type = "sine"; osc.frequency.value = 528;
        osc2.type = "sine"; osc2.frequency.value = 1056.4;
        filter.type = "lowpass"; filter.frequency.value = 2400;
      } else if (kind === "tibetan") {
        osc.type = "triangle"; osc.frequency.value = 216;
        osc2.type = "sine"; osc2.frequency.value = 432;
        filter.type = "bandpass"; filter.frequency.value = 520;
      } else if (kind === "chimes") {
        osc.type = "sine"; osc.frequency.value = 880;
        osc2.type = "sine"; osc2.frequency.value = 1320;
        filter.type = "highpass"; filter.frequency.value = 700;
      } else {
        osc.type = "sawtooth"; osc.frequency.value = 110;
        osc2.type = "triangle"; osc2.frequency.value = 220;
        filter.type = "lowpass"; filter.frequency.value = 900;
      }

      const lfo = ctx.createOscillator();
      const lfoGain = ctx.createGain();
      lfo.type = "sine";
      lfo.frequency.value = kind === "chimes" ? 0.4 : 0.09;
      lfoGain.gain.value = kind === "chimes" ? 0.07 : 0.04;

      lfo.connect(lfoGain).connect(gain.gain);
      osc.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);

      osc.start(); osc2.start(); lfo.start();
      layer.osc = osc;
      layer.osc2 = osc2;
      layer.lfo = lfo;
      layer.filter = filter;
    }

    return layer;
  }
};
