const engine = window.audioEngine;
const $ = (id) => document.getElementById(id);

function setStatus(text) {
  $("status").innerText = text;
}

function renderLayers() {
  const box = $("layers");
  box.innerHTML = engine.layers.length ? "" : "<p class='note'>No frequency layers yet.</p>";

  engine.layers.forEach((layer) => {
    const div = document.createElement("div");
    div.className = "layer";
    div.innerHTML = `
      <div class="layer-top">
        <div><strong>${layer.freq} Hz</strong><br><span class="note">${layer.wave}</span></div>
        <button class="danger" data-remove-freq="${layer.id}">Remove</button>
      </div>
      <label>Frequency</label>
      <input type="number" value="${layer.freq}" data-freq="${layer.id}">
      <label>Volume</label>
      <input type="range" min="0" max=".6" step=".01" value="${layer.volume}" data-volume="${layer.id}">
      <label>Pan Left / Right</label>
      <input type="range" min="-1" max="1" step=".01" value="${layer.pan}" data-pan="${layer.id}">
      <div class="layer-buttons">
        <button class="secondary" data-mute="${layer.id}">${layer.muted ? "Unmute" : "Mute"}</button>
        <button class="secondary" data-solo="${layer.id}">${engine.soloId === layer.id ? "Unsolo" : "Solo"}</button>
        <button class="secondary" data-duplicate="${layer.id}">Duplicate</button>
      </div>
    `;
    box.appendChild(div);
  });
}

function renderSoundLayers() {
  const box = $("soundLayers");
  box.innerHTML = engine.soundLayers.length ? "" : "<p class='note'>No sound library layers yet.</p>";

  engine.soundLayers.forEach((layer) => {
    const div = document.createElement("div");
    div.className = "layer";
    div.innerHTML = `
      <div class="layer-top">
        <div><strong>${prettyName(layer.kind)}</strong><br><span class="note">Sound library layer</span></div>
        <button class="danger" data-remove-sound="${layer.id}">Remove</button>
      </div>
      <label>Volume</label>
      <input type="range" min="0" max=".6" step=".01" value="${layer.volume}" data-volume="${layer.id}">
      <label>Pan Left / Right</label>
      <input type="range" min="-1" max="1" step=".01" value="${layer.pan}" data-pan="${layer.id}">
      <div class="layer-buttons">
        <button class="secondary" data-mute="${layer.id}">${layer.muted ? "Unmute" : "Mute"}</button>
        <button class="secondary" data-solo="${layer.id}">${engine.soloId === layer.id ? "Unsolo" : "Solo"}</button>
        <button class="secondary" data-duplicate-sound="${layer.id}">Duplicate</button>
      </div>
    `;
    box.appendChild(div);
  });
}

function prettyName(kind) {
  return kind.replace(/\b\w/g, c => c.toUpperCase()).replace("_", " ");
}

function renderSessions() {
  const box = $("sessions");
  const sessions = JSON.parse(localStorage.getItem("unpaintedSessionsV4") || "[]");
  box.innerHTML = sessions.length ? "" : "<p class='note'>No saved sessions yet.</p>";

  sessions.forEach((session, index) => {
    const div = document.createElement("div");
    div.className = "session";
    const freqs = (session.layers || []).map(l => `${l.freq}Hz`).join(", ");
    const sounds = (session.soundLayers || []).map(l => prettyName(l.kind)).join(", ");
    div.innerHTML = `
      <strong>${session.name}</strong>
      <p class="note">${freqs || "No frequencies"}<br>${sounds || "No sounds"}</p>
      <button data-load-session="${index}">Load Session</button>
    `;
    box.appendChild(div);
  });
}

$("masterVolume").addEventListener("input", e => engine.setMasterVolume(e.target.value));
$("reverbMix").addEventListener("input", e => engine.setReverb(e.target.value));
$("delayMix").addEventListener("input", e => engine.setDelay(e.target.value));

$("fadeInBtn").addEventListener("click", () => {
  engine.fadeTo(Number($("masterVolume").value), 5);
  setStatus("Fading in");
});

$("fadeOutBtn").addEventListener("click", () => {
  engine.fadeTo(0, 5);
  setStatus("Fading out");
});

$("stopAllBtn").addEventListener("click", () => {
  engine.stopAll();
  renderLayers();
  renderSoundLayers();
  setStatus("Stopped all audio");
});

$("addLayerBtn").addEventListener("click", () => {
  engine.addFrequencyLayer($("freqInput").value, $("waveInput").value, 0.12, 0);
  renderLayers();
  setStatus(`${$("freqInput").value} Hz added`);
});

document.querySelectorAll("[data-preset]").forEach(btn => {
  btn.addEventListener("click", () => {
    engine.addFrequencyLayer(btn.dataset.preset, $("waveInput").value, 0.12, 0);
    renderLayers();
    setStatus(`${btn.dataset.preset} Hz added`);
  });
});

document.querySelectorAll("[data-sound]").forEach(btn => {
  btn.addEventListener("click", () => {
    engine.addGeneratedSound(btn.dataset.sound, 0.13, 0);
    renderSoundLayers();
    setStatus(`${prettyName(btn.dataset.sound)} added`);
  });
});

document.addEventListener("input", e => {
  if (e.target.dataset.freq !== undefined) {
    engine.updateLayer(e.target.dataset.freq, { freq:e.target.value });
    renderLayers();
  }
  if (e.target.dataset.volume !== undefined) {
    engine.updateLayer(e.target.dataset.volume, { volume:e.target.value });
  }
  if (e.target.dataset.pan !== undefined) {
    engine.updateLayer(e.target.dataset.pan, { pan:e.target.value });
  }
});

document.addEventListener("click", e => {
  if (e.target.dataset.removeFreq !== undefined) {
    engine.removeLayer(e.target.dataset.removeFreq, "frequency");
    renderLayers();
    setStatus("Frequency layer removed");
  }

  if (e.target.dataset.removeSound !== undefined) {
    engine.removeLayer(e.target.dataset.removeSound, "sound");
    renderSoundLayers();
    setStatus("Sound layer removed");
  }

  if (e.target.dataset.mute !== undefined) {
    engine.toggleMute(e.target.dataset.mute);
    renderLayers();
    renderSoundLayers();
  }

  if (e.target.dataset.solo !== undefined) {
    engine.toggleSolo(e.target.dataset.solo);
    renderLayers();
    renderSoundLayers();
  }

  if (e.target.dataset.duplicate !== undefined) {
    const layer = engine.layers.find(l => l.id === e.target.dataset.duplicate);
    if (layer) engine.addFrequencyLayer(layer.freq, layer.wave, layer.volume, layer.pan);
    renderLayers();
  }

  if (e.target.dataset.duplicateSound !== undefined) {
    const layer = engine.soundLayers.find(l => l.id === e.target.dataset.duplicateSound);
    if (layer) engine.addGeneratedSound(layer.kind, layer.volume, layer.pan);
    renderSoundLayers();
  }

  if (e.target.dataset.loadSession !== undefined) {
    const sessions = JSON.parse(localStorage.getItem("unpaintedSessionsV4") || "[]");
    const session = sessions[Number(e.target.dataset.loadSession)];
    if (session) {
      engine.loadSnapshot(session);
      renderLayers();
      renderSoundLayers();
      setStatus("Session loaded");
    }
  }
});

$("binauralBtn").addEventListener("click", () => {
  engine.startBinaural($("binauralCarrier").value, $("binauralBeat").value, 0.12);
  setStatus(`Binaural ${$("binauralBeat").value} Hz`);
});

$("isoBtn").addEventListener("click", () => {
  engine.startIsochronic($("isoCarrier").value, $("isoPulse").value);
  setStatus(`Isochronic ${$("isoPulse").value} Hz`);
});

$("saveSessionBtn").addEventListener("click", () => {
  const sessions = JSON.parse(localStorage.getItem("unpaintedSessionsV4") || "[]");
  const snapshot = engine.snapshot();
  snapshot.name = $("sessionName").value.trim() || `Session ${sessions.length + 1}`;
  sessions.push(snapshot);
  localStorage.setItem("unpaintedSessionsV4", JSON.stringify(sessions));
  renderSessions();
  setStatus("Session saved");
});

startVisualizer(engine);
renderLayers();
renderSoundLayers();
renderSessions();

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("./sw.js").catch(() => {});
}
