# Unpainted Souls V5

New: quick guided sessions, guided voice, breath pacer, sleep timer with fade-out, mixer, sound library, saved sessions.
